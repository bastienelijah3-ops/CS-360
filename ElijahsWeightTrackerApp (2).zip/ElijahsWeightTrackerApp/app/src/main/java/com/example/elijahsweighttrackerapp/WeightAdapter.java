package com.example.elijahsweighttrackerapp;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import com.example.elijahsweighttrackerapp.R;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(WeightEntry entry);
        void onDeleteClick(long id);
    }

    private List<WeightEntry> entryList;
    private OnItemClickListener listener;

    public WeightAdapter(List<WeightEntry> entryList, OnItemClickListener listener) {
        this.entryList = entryList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_row, parent, false);
        return new WeightViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = entryList.get(position);
        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(String.format("%.1f lbs", entry.getWeight()));

        holder.itemView.setOnClickListener(v -> listener.onItemClick(entry));
        holder.btnDelete.setOnClickListener(v -> listener.onDeleteClick(entry.getId()));
    }

    @Override
    public int getItemCount() {
        return entryList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        ImageButton btnDelete;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvRowDate);
            tvWeight = itemView.findViewById(R.id.tvRowWeight);
            btnDelete = itemView.findViewById(R.id.btnDeleteRow);
        }
    }
}