package com.example.elijahsweighttrackerapp;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.example.elijahsweighttrackerapp.R;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        tvStatus = findViewById(R.id.tvSmsStatusMessage);
        Button btnAllow = findViewById(R.id.btnAllowSms);
        Button btnDeny = findViewById(R.id.btnDenySms);
        Button btnReturn = findViewById(R.id.btnReturnDashboard);

        updateStatusUI();

        btnAllow.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                updateStatusUI();
            }
        });

        btnDeny.setOnClickListener(v -> {
            tvStatus.setText("Status: Permission Denied. Application functions without SMS alerts.");
        });

        btnReturn.setOnClickListener(v -> finish());
    }

    private void updateStatusUI() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            tvStatus.setText("Status: SMS Milestone Alerts Active");
        } else {
            tvStatus.setText("Status: Permission Pending / Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                updateStatusUI();
            } else {
                tvStatus.setText("Status: Permission Denied. Application functions without SMS alerts.");
            }
        }
    }
}