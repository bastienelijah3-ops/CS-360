package com.example.elijahsweighttrackerapp;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;
import com.example.elijahsweighttrackerapp.R;

public class DataDisplayActivity extends AppCompatActivity implements WeightAdapter.OnItemClickListener {

    private DatabaseHelper dbHelper;
    private int userId;
    private String username;
    private double targetGoal = 0.0;

    private TextView tvUserWelcome, tvTargetWeightValue;
    private RecyclerView rvWeightGrid;
    private WeightAdapter adapter;
    private List<WeightEntry> entryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        userId = prefs.getInt("USER_ID", -1);
        username = prefs.getString("USERNAME", "User");

        tvUserWelcome = findViewById(R.id.tvUserWelcome);
        tvTargetWeightValue = findViewById(R.id.tvTargetWeightValue);
        rvWeightGrid = findViewById(R.id.rvWeightGrid);
        FloatingActionButton fabAdd = findViewById(R.id.fabAddWeight);
        Button btnNavSms = findViewById(R.id.btnNavSmsSettings);
        Button btnUpdateGoal = findViewById(R.id.btnUpdateGoal);

        tvUserWelcome.setText("Welcome, " + username);

        // Display Data Grid with 1 column (vertical list of card rows matching grid layout)
        rvWeightGrid.setLayoutManager(new GridLayoutManager(this, 1));
        entryList = new ArrayList<>();
        adapter = new WeightAdapter(entryList, this);
        rvWeightGrid.setAdapter(adapter);

        fabAdd.setOnClickListener(v -> showEntryDialog(null));
        btnNavSms.setOnClickListener(v -> startActivity(new Intent(this, SmsPermissionActivity.class)));
        btnUpdateGoal.setOnClickListener(v -> showGoalDialog());

        loadUserData();
    }

    private void loadUserData() {
        targetGoal = dbHelper.getGoalWeight(userId);
        tvTargetWeightValue.setText(targetGoal > 0 ? targetGoal + " lbs" : "Not Set");

        entryList.clear();
        Cursor cursor = dbHelper.getAllEntriesForUser(userId);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ENTRY_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_VALUE));
                entryList.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    private void showGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();

        TextInputEditText etWeight = view.findViewById(R.id.etDialogWeight);
        TextInputEditText etDate = view.findViewById(R.id.etDialogDate);
        Button btnSave = view.findViewById(R.id.btnSaveWeightEntry);
        Button btnCancel = view.findViewById(R.id.btnCancelDialog);

        etDate.setVisibility(View.GONE);
        etWeight.setHint("Target Weight (lbs)");

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSave.setOnClickListener(v -> {
            String val = etWeight.getText().toString().trim();
            if (!val.isEmpty()) {
                double newGoal = Double.parseDouble(val);
                dbHelper.updateGoalWeight(userId, newGoal);
                loadUserData();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showEntryDialog(WeightEntry existingEntry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();

        TextInputEditText etWeight = view.findViewById(R.id.etDialogWeight);
        TextInputEditText etDate = view.findViewById(R.id.etDialogDate);
        Button btnSave = view.findViewById(R.id.btnSaveWeightEntry);
        Button btnCancel = view.findViewById(R.id.btnCancelDialog);

        if (existingEntry != null) {
            etWeight.setText(String.valueOf(existingEntry.getWeight()));
            etDate.setText(existingEntry.getDate());
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSave.setOnClickListener(v -> {
            String wStr = etWeight.getText().toString().trim();
            String dStr = etDate.getText().toString().trim();

            if (!wStr.isEmpty() && !dStr.isEmpty()) {
                double weight = Double.parseDouble(wStr);
                if (existingEntry == null) {
                    dbHelper.addWeightEntry(userId, dStr, weight);
                    checkGoalAndTriggerSms(weight);
                } else {
                    dbHelper.updateWeightEntry(existingEntry.getId(), dStr, weight);
                }
                loadUserData();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void checkGoalAndTriggerSms(double currentWeight) {
        if (targetGoal > 0 && currentWeight <= targetGoal) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("5555555555", null,
                            "Goal Reached! Congratulations, you logged " + currentWeight + " lbs!", null, null);
                    Toast.makeText(this, "Milestone achieved! SMS notification sent.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void onItemClick(WeightEntry entry) {
        showEntryDialog(entry);
    }

    @Override
    public void onDeleteClick(long id) {
        dbHelper.deleteWeightEntry(id);
        loadUserData();
        Toast.makeText(this, "Record deleted", Toast.LENGTH_SHORT).show();
    }
}