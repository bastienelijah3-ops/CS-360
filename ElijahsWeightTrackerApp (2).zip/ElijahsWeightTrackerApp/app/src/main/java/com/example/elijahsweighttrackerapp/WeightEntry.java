package com.example.elijahsweighttrackerapp;
public class WeightEntry {
    private long id;
    private String date;
    private double weight;

    public WeightEntry(long id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() { return id; }
    public String getDate() { return date; }
    public double getWeight() { return weight; }
}